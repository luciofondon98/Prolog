Integrantes:
Luis Elicer Krause,	rol: 201773513-9
Lucio Fondon, 		rol: 201773610-0
Paralelo 200

Instrucciones para utilizar la tarea:
1-. Cargar cada archivo (gablema.pl y pantema.pl) en SWI-Prolog.
2-. Para gablema.pl, realizar consultas de la forma relacion(X, L), donde L ser� el retorno y X el nombre de la persona
a consultar
3-. Para pantema.pl, realizar consultas de la forma alcanzables(Ciudad, Tiempo, L), donde L es la lista de ciudades alcanzables.